SELLBA is an android app for selling and buying of new/old baterys.
## Tools and Technology
- Android Studio
- Firebase
- Java 8

## Build Config
- Api 28
- Gradle: 7.2



## License
Copyright (c) 2022 SELLBA company
