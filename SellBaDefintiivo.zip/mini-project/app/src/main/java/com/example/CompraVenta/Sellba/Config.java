package com.example.CompraVenta.Sellba;

public class Config {
    public static final String EMAIL = "sellbacompany@gmail.com";
    public static final String PASSWORD = "sellba123";
}
