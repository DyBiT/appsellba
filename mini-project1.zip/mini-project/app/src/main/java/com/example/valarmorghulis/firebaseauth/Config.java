package com.example.valarmorghulis.firebaseauth;

public class Config {
    public static final String EMAIL = "";
    public static final String PASSWORD = "";
}
